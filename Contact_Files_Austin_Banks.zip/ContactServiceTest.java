package test;

import src.Contact;

import src.ContactService;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testAddContactUniqueId() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		service.addContact(contact);
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			service.addContact(new Contact("12345", "Blue", "Bowl", "5555555555", "5678 Green Street"));
		});
	}

	@Test
	void testAddContactNull() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class,()->{
			service.addContact(null);
		});
	}
	
	@Test
	void testDeleteContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		service.deleteContact("12345");
		
		assertThrows(IllegalArgumentException.class,()->{
			service.updateFirstName("12345","Name");
		});
	}
	@Test
	void testDeleteContactIdNull() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class, ()->{
			service.deleteContact(null);
		});
	}
	
	@Test
	void testDeleteContactInvalidId() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class, ()->{
			service.deleteContact("98765");
		});
	}
	
	@Test 
	void testUpdateFirstName(){
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		service.updateFirstName("12345", "NewName");
		
		assertTrue(contact.getFirstName().equals("NewName"));
	}
	
	@Test
	void testUpdateFirstNameInvalidId() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class,()->{
			service.updateFirstName("2342", "Name");
			});
	}
	
	@Test
	void testUpateFirstNameLong() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		service.addContact(contact);
		
		assertThrows(IllegalArgumentException.class,()->{
			service.updateFirstName("12345", "This name is longer than the allowed amount");
		});
	}
	
	@Test 
	void testUpdateFirstNameNull() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		service.addContact(contact);
		
		assertThrows(IllegalArgumentException.class,()->{
			service.updateFirstName("12345", null);
		});
	}
	
	@Test
	void testUpdateFirstNameIdNull() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		service.addContact(contact);
		
		assertThrows(IllegalArgumentException.class,()->{
			service.updateFirstName(null, "Name");
		});
	}
	@Test
	void testUpdateLastName() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		service.updateLastName("12345", "NewName");
		
		assertTrue(contact.getLastName().equals("NewName"));
	}
	
	@Test
	void testUpdateNameInvalidId() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class,()->{
			service.updateLastName("2342", "Name");
			});
	}
	
	@Test 
	void testUpdateLastNameLong(){
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class,()->{
			service.updateLastName("12345", "This Last Name is too Long");
			});
	}
	
	@Test
	void testUpdateLastNameNull(){
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class,()->{
			service.updateLastName("12345", null);
			});
	}
	
	@Test
	void testUpdateLasttNameIdNull() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		service.addContact(contact);
		
		assertThrows(IllegalArgumentException.class,()->{
			service.updateLastName(null, "NewLast");
		});
	}
	@Test
	void testUpdatePhone() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		service.updatePhone("12345", "1987654321");
		
		assertTrue(contact.getPhone().equals("1987654321"));
	}
	
	@Test
	void testUpdatePhoneInvalidId() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class,()->{
			service.updatePhone("2342", "1234567890");
			});
	}
	
	@Test
	void testUpdatePhoneIdNull() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		service.addContact(contact);
		
		assertThrows(IllegalArgumentException.class,()->{
			service.updatePhone(null, "1987654321");
		});
	}
	
	@Test
	void testUpdatePhoneNonDigit() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class,()->{
			service.updatePhone("12345", "ABCDEFGHIJ");
			});
	}
	
	@Test
	void testUpdatePhoneLong(){
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class,()->{
			service.updatePhone("12345", "12345678901");
			});
	}
	
	@Test
	void testUpdatePhoneShort() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class,()->{
			service.updatePhone("12345", "123456789");
			});
	}
	
	@Test
	void testUpdateAddress() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		service.updateAddress("12345", "1234 Red Lane");
		
		assertTrue(contact.getAddress().equals("1234 Red Lane"));
	}
	
	@Test
	void testUpdateAddressInvalidId() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class,()->{
			service.updateAddress("2342", "Address");
			});
	}
	
	@Test
	void testUpdateAddressLong() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class,()->{
			service.updateAddress("12345", "This address is way too long to be under the allowed amount");
			});
	}
	
	@Test
	void testUpdateAddressNull() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class,()->{
			service.updateAddress("12345", null);
			});
	}

	@Test
	void testUpdateAddressIdNull() {
		ContactService service = new ContactService();
		Contact contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		service.addContact(contact);
	
		assertThrows(IllegalArgumentException.class,()->{
			service.updateAddress(null, "1234 Red Lane");
		});
	}
}
