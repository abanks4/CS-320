package src;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

	//Stores contacts using Contact ID
    private Map<String, Contact> contacts = new HashMap<>();

    //Adds new contact, The new Contact ID must be unique
    public void addContact(Contact contact){
        if (contact == null){
            throw new IllegalArgumentException("Invalid Contact Id");
        }
        if(contacts.containsKey(contact.getContactId())) {
        	throw new IllegalArgumentException("Contact Id already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }

    //Deletes a contact using Contact ID
    public void deleteContact(String contactId){
    	if(!contacts.containsKey(contactId)) {
    		throw new IllegalArgumentException("Contact Id not found");
    	}
        contacts.remove(contactId);
        }
    
    	//Updates first name of a contact using the Contact ID
        public void updateFirstName(String contactId, String firstName){
            Contact contact = contacts.get(contactId);
            if (contact == null) {
            	throw new IllegalArgumentException("Contact Id not found");
            }
                contact.setFirstName(firstName);
            }
           
        //Updates the last name of a contact using the Contact ID    
        public void updateLastName(String contactId, String lastName) {
            Contact contact = contacts.get(contactId);
            if (contact == null) {
            	throw new IllegalArgumentException("Contact ID not found");
            }
                contact.setLastName(lastName);
            }
        
        //Updates the phone number of a contact using the Contact ID
        public void updatePhone(String contactId, String phone){
            Contact contact = contacts.get(contactId);
            if (contact == null) {
            	throw new IllegalArgumentException("Contact ID not found");
            }
                contact.setPhone(phone);
                }
                   
        //Updates the address of a contact using the Contact ID
        public void updateAddress(String contactId, String address){
            Contact contact = contacts.get(contactId);
            if (contact == null) {
            	throw new IllegalArgumentException("Contact ID not found");
            }
             contact.setAddress(address);
            }
        }