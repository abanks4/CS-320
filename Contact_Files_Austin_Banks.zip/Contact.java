package src;

public class Contact {
	// Immutable Contact ID
    private final String contactId;
    
    //Updatable fields
    private String firstName;
    private String lastName;
    private String phone;
    private String address;
    
    
    //Constructor that validates fields
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
    	
    	validateContactId(contactId);
        //Assign fields
        this.contactId = contactId;
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }
    
    //Getters for all fields
    public String getContactId(){
        return contactId;
    }
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }

    public String getPhone(){
        return phone;
    }

    public String getAddress(){
        return address;
    }

    //Setters for all fields with validation
    public void setFirstName(String firstName) {
    	validateFirstName(firstName);
        this.firstName = firstName;
    	}
    public void setLastName(String lastName) {
        validateLastName(lastName);
        this.lastName = lastName;
        }

    public void setPhone(String phone) {
    	 validatePhone(phone);
        this.phone = phone;
    }

    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }
    
   // Validation methods for each field 
    private static void validateContactId(String contactId) {
    	if (contactId == null) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
    	if (contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
    	if(!contactId.matches("\\d+")) {
    		throw new IllegalArgumentException("Invalid contact Id");
    	}
    	
    }
    
    private static void validateFirstName(String firstName) {
    	if (firstName== null) {
            throw new IllegalArgumentException("Invalid first name");
        }
    	if (firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
    }
    
    private static void validateLastName(String lastName) {
    	if (lastName == null) {
            throw new IllegalArgumentException("Invalid last name");
        }
    	if (lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
    }
    
    private static void validatePhone(String phone) {
    	if (phone == null) {
            throw new IllegalArgumentException("Invalid phone");
   	 }
    	if (!phone.matches("\\d+")) {
            throw new IllegalArgumentException("Invalid phone");
   	 }
    	if (phone.length() != 10) {
            throw new IllegalArgumentException("Invalid phone");
   	 }
    }
    
    private static void validateAddress(String address) {
    	if (address == null) {
            throw new IllegalArgumentException("Invalid address");
        }
    	if (address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
    }
}
