package test;

import src.Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



class ContactTest {

	@Test
	void testContactClass() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
	    assertTrue(Contact.getContactId().equals("12345"));
		assertTrue(Contact.getFirstName().equals("First"));
		assertTrue(Contact.getLastName().equals("Last"));
		assertTrue(Contact.getPhone().equals("1234567891"));
		assertTrue(Contact.getAddress().equals("1234 Blue Lane"));
	}
	
	@Test
	void testContactIdLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234567891020", "First", "Last", "1234567891", "1234 Blue Lane");
		});
	}
	@Test
	void testContactIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null, "First", "Last", "1234567891", "1234 Blue Lane");
		});
	}
	@Test
	void testFirstNameLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "abcdefghijkl", "Last", "1234567891", "1234 Blue Lane");
		});
	}
	@Test
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", null, "Last", "1234567891", "1234 Blue Lane");
		});
	}
	@Test
	void testLastNameLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", "abcdefghijkl", "1234567891", "1234 Blue Lane");
		});
	}
	@Test
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", null, "1234567891", "1234 Blue Lane");
		});
	}
	@Test
	void testPhoneGreaterTen() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", "Last", "123456789123", "1234 Blue Lane");
		});
	}
	
	@Test
	void testPhoneLessTen() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", "Last", "123456789", "1234 Blue Lane");
		});
	}
	
	@Test
	void testPhoneNonDigit() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", "Last", "abcdefghij", "1234 Blue Lane");
		});
	}
	
	@Test
	void testPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", "Last", null, "1234 Blue Lane");
		});
	}
	@Test
	void testAddressLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", "Last", "1234567891", "1234 Blue Lane 1234 Blue Lane 1234 Blue Lane 1234 Blue Lane");
		});
	}
	@Test
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234", "First", "Last", "1234567891", null);
		});
	}
	
	@Test
	void testSetFirstNameValid() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		Contact.setFirstName("First");
		assertEquals("First", Contact.getFirstName());		
	}
	
	@Test
	void testSetFirstNameNull() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
				assertThrows(IllegalArgumentException.class,()->{
					Contact.setFirstName(null);
		});
	}
	
	@Test
	void testSetFirstNameLong() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
				assertThrows(IllegalArgumentException.class,()->{
					Contact.setFirstName("This first name is too long");
		});
	}

	@Test
	void testSetLastNameValid() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		Contact.setLastName("Name");
		assertEquals("Name",Contact.getLastName());
	}
	
	@Test
	void testSetLastNameNull() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
			Contact.setLastName(null);
		});
	}
	
	@Test
	void testSetLastNameLong() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
			Contact.setLastName("This last name is too long");
		});
	}
	
	@Test 
	void testSetPhoneValid(){
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		Contact.setPhone("1234567892");
		assertEquals("1234567892",Contact.getPhone());
	}
	
	@Test
	void testSetPhoneNull() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
			Contact.setPhone(null);
		});
	}
	
	@Test
	void testSetPhoneLong() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
		Contact.setPhone("12345678910");
				});
	}
	
	@Test
	void testSetPhoneShort() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
		Contact.setPhone("123456789");
				});
	}
	
	@Test
	void testSetPhoneNonDigit() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
		Contact.setPhone("abcdefghij");
				});
	}
	
	@Test
	void testSetAddressValid() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		Contact.setAddress("4321 Blue Lane");
		assertEquals("4321 Blue Lane", Contact.getAddress());
	}
	
	@Test 
	void testSetAddressNull() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
			Contact.setAddress(null);
		});
	}
	
	@Test void testSetAddressLong() {
		Contact Contact = new Contact("12345", "First", "Last", "1234567891", "1234 Blue Lane");
		assertThrows(IllegalArgumentException.class,()->{
			Contact.setAddress("This address is over 20 charactersss");
		});
	}
}


